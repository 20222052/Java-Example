package org.example.chuong4_bai3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chuong4Bai3Application {

    public static void main(String[] args) {
        SpringApplication.run(Chuong4Bai3Application.class, args);
    }

}
